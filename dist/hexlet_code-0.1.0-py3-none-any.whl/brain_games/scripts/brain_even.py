#!/usr/bin/env python3
from brain_games.games.game import *
from brain_games.games.even import even


def main():
    welcome()
    name = welcome_user()
    even(name)



    




    
    




