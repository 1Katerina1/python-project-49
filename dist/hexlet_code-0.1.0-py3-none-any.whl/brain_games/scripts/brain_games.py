#!/usr/bin/env python3
from brain_games.games.game import *


def main():
    welcome()
    welcome_user()