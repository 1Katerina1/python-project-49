#!/usr/bin/env python3


from brain_games.games.general_logic import welcome
from brain_games.games.general_logic import welcome_user


def main():
    welcome()
    welcome_user()
