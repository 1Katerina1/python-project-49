### Hexlet tests and linter status:
[![Actions Status](https://github.com/1Katerina1/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/1Katerina1/python-project-49/actions)

<a href="https://codeclimate.com/github/1Katerina1/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/cbeb36e2fc3c5748d0c9/maintainability" /></a>
